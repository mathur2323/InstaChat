import React, { Component } from 'react'

class Contacts extends Component {
    render() {
        return (
            <div>
                <h1>Contacts</h1>                
            </div>
        )
    }
}

export default Contacts
