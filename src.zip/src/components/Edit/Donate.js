import React, { Component } from 'react'

class Donate extends Component {
    render() {
        return (
            <div>
                <h1>Donate</h1>                
            </div>
        )
    }
}

export default Donate
