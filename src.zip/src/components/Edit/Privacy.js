import React, { Component } from 'react'

class Privacy extends Component {
    render() {
        return (
            <div>
                <h1>Privacy</h1>                
            </div>
        )
    }
}

export default Privacy
