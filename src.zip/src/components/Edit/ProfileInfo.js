import React, { Component } from 'react'

class ProfileInfo extends Component {
    render() {
        return (
            <div>
                <div>
                    <img src="" />
                </div>
                <div>
                    <h3>Username</h3>
                </div>
            </div>
        )
    }
}

export default ProfileInfo
