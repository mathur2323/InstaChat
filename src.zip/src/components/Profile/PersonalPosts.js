import React, { Component } from 'react'
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Image from 'react-bootstrap/Image'

class PersonalPosts extends Component {
    render() {
        return (
           <Row>
               <Col>
                    <Image src='https://via.placeholder.com/150' />
               </Col>
           </Row>
        )
    }
}

export default PersonalPosts
