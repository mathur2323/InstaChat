const profileData = (state,action)=>{
    switch(action.type){
        default:
            return state
    }
}
export default profileData