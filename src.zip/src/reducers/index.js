import profileInfo from './reducer.profileInfo'
import profileData from './reducer.profileData'

export { profileInfo, profileData }