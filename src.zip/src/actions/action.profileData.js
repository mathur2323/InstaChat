import * as actionType from './../constants';

export default getProfileData = () => ({
    type:actionType.GET_USER_PROFILE_DATA_ASYNC    
})